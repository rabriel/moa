<?php

namespace App\Http\Controllers;

use App\Models\Player;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;

class RegistrationController extends Controller
{
    public function index(Request $request): View|RedirectResponse
    {
        if ($request->session()->has('player_id')) {
            return redirect()->route('game.index');
        }

        return view('registration.index');
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'surname' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:players,email'],
            'cell_phone' => ['required', 'string', 'max:30', 'unique:players,cell_phone'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $request->session()->regenerate();

        $player = Player::create([
            ...collect($validated)->except('password', 'password_confirmation')->all(),
            'password' => Hash::make($validated['password']),
            'session_token' => $request->session()->getId(),
        ]);

        $request->session()->put('player_id', $player->id);

        return redirect()
            ->route('scan.show', ['store' => 'ackermans', 'intro' => 1])
            ->with('status', "You're In! Let the Banana Hunt Begin!");
    }
}
